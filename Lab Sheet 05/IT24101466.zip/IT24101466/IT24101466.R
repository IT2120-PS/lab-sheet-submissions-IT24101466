setwd("C:\\Users\\it24101466\\Desktop\\IT24101466")
Delivery_Times<- read.table("Exercise - Lab 05.txt", header = TRUE )
fix(Delivery_Times)

attach(Delivery_Times)
histogram <- hist(Delivery_Time_.minutes. , main = "Histogram", breaks = seq(20, 70, length= 10), right = TRUE)

breaks =histogram$breaks 
frequency = histogram$counts
cum.freq = cumsum(frequency)
cum.freq

new<- c()
for(i in 1:length(breaks)){
  if(i ==1){
    new[i]= 0
  }else{
    new[i] = cum.freq[i-1]
  }
}
new

plot(breaks, new, type = 'l', main = "Cumulative frequency", xlab = "Minutes", ylab = "Cumulative Frequency")
max