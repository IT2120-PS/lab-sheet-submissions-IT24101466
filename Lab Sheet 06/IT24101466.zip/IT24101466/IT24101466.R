#1.ii)
pbinom(46,50,0.85, lower.tail = FALSE)

#2. iii)
dpois(15, 12)
