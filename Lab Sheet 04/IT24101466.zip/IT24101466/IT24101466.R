setwd("C:\\Users\\it24101466\\Desktop\\IT24101466")

#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

fix(branch_data)


#2
class(branch_data$Sales_X1)
class(branch_data$Advertising_X2)
class(branch_data$Years_X3)

#3
boxplot(branch_data$Sales_X1, main = "Boxplot for sales", outline = TRUE, outpch = 8, horizontal = TRUE)

#Q4
# five number summary
quantile(branch_data$Advertising_X2)

#IQR
IQR(branch_data$Advertising_X2)

#Q5

outliers = function(v){
  q1<- quantile(v)[2]
  q3<- quantile(v)[4]
  iqr<- q3-q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5 *iqr
  
  print(paste("Upper bound: ", ub))
  print(paste("lower bound: ", lb))
  print(paste("Outliers: ", paste(sort(v[v<lb | v >ub]), collapse = "," )))
  
  
}

outliers(branch_data$Years_X3)
